﻿namespace CuentaBanco
{
    class Proyecto1B
    {
        static void Main(string[] args)
        {
            /*
            Proyecto 1-b
            1278724 - Pablo José Cabrera González
            1050324 - Javier Alexander Castellanos Oliva
            1309924 - Johan Eduardo Escobar Manzaneros
            */

            string Tipocuenta, nombre, dpi, direccion, NumeroTelefono;
            double BalanceCuenta = 2500;
            int abonos = 0;
            int opcion;
            int periodo;
            double cbf;

            Console.WriteLine("Tipo de cuenta que desea utilizar (monetaria quetzales, monetaria dólares, ahorro quetzales, ahorro dólares): ");
            Tipocuenta = Console.ReadLine();
            Console.WriteLine("Bienvenido al Banco");
            Console.WriteLine("Ingrese su nombre: ");
            nombre = Console.ReadLine();
            Console.WriteLine("Ingrese 5 dígitos de su DPI: ");
            dpi = Console.ReadLine();
            if (dpi.Length != 5)
            {
                Console.WriteLine("No es válido el dato");
                Console.WriteLine("Ingrese 5 dígitos de su DPI: ");
                dpi = Console.ReadLine();
                if (dpi.Length != 5)
                {
                    Console.WriteLine("No es válido el dato y la sesión a cerrado");
                }
                else
                    Console.WriteLine("Ingrese su dirección: ");
                direccion = Console.ReadLine();
                Console.WriteLine("Ingrese su número telefónico: ");
                NumeroTelefono = Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Ingrese su dirección: ");
                direccion = Console.ReadLine();
                Console.WriteLine("Ingrese su número telefónico: ");
                NumeroTelefono = Console.ReadLine();
            }

            do
            {
                Console.WriteLine("Seleccione una opción: ");
                Console.WriteLine("1. Ver información de la cuenta");
                Console.WriteLine("2. Comprar producto financiero");
                Console.WriteLine("3. Vender producto financiero");
                Console.WriteLine("4. Abonar a una cuenta");
                Console.WriteLine("5. Simulación Paso del Tiempo");
                Console.WriteLine("6. Salir");
                opcion = Convert.ToInt32(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("Información de la cuenta: ");
                        Console.WriteLine("Tipo de cuenta: " + Tipocuenta);
                        Console.WriteLine("Nombre: " + nombre);
                        Console.WriteLine("DPI: " + dpi);
                        Console.WriteLine("Dirección: " + direccion);
                        Console.WriteLine("Número telefónico: " + NumeroTelefono);
                        Console.WriteLine("Saldo actual: Q" + BalanceCuenta.ToString("F2"));
                        break;
                    case 2:
                        cbf = BalanceCuenta - (BalanceCuenta * 0.10);
                        Console.WriteLine("Su cuenta bancaria es de Q" + cbf.ToString("F2") + " actualmente");
                        BalanceCuenta = cbf;
                        break;
                    case 3:
                        if (BalanceCuenta > 500)
                        {
                            BalanceCuenta = BalanceCuenta * 1.11;
                            Console.WriteLine("Su cuenta bancaria es de Q" + BalanceCuenta.ToString("F2") + " actualmente");
                        }
                        else
                        {
                            Console.WriteLine("Se recomienda no realizar esta acción debido al saldo actual.");
                            Console.WriteLine("Porcentaje de ganancia: " + (BalanceCuenta * 0.11).ToString("F2") + "%");
                        }
                        break;
                    case 4:
                        if (abonos < 2 && BalanceCuenta <= 500)
                        {
                            BalanceCuenta = BalanceCuenta * 2;
                            Console.WriteLine("Abono realizado exitosamente.");
                            Console.WriteLine("Saldo actual: Q" + BalanceCuenta.ToString("F2"));
                            abonos++;
                        }
                        else
                        {
                            Console.WriteLine("La presente actividad no es permitida por su saldo actual");
                        }
                        break;
                    case 5:
                        Console.WriteLine("¿Qué periodo de capitalización desea utilizar? (1 para una vez al mes, 2 para dos veces al mes): ");
                        periodo = Convert.ToInt32(Console.ReadLine());
                        if (periodo == 1)
                        {
                            BalanceCuenta = BalanceCuenta * 1.02;
                        }
                        else if (periodo == 2)
                        {
                            BalanceCuenta = BalanceCuenta * 1.04;
                        }
                        else
                        {
                            Console.WriteLine("Opción no válida, vuelva a seleccionar otra");
                        }
                        Console.WriteLine("Saldo actual: Q" + BalanceCuenta.ToString("F2"));
                        break;
                    case 6:
                        Console.WriteLine("Sesión cerrada.");
                        break;
                    default:
                        Console.WriteLine("La opción ingresada no es válida, vuelva a seleccionar una opción válida del siguiente listado");
                        break;
                }
            } while (opcion != 6);
        }
    }
}